
import streamlit as st

st.set_page_config(page_title="养老机构效率计算器", layout="centered")

st.title("🏥 养老机构效率计算器")
st.markdown("请根据您的数据选择要计算的模块，并输入相关参数（单位：元）")

eff_type = st.selectbox("选择要计算的效率类型", ["坪效（单位面积产出）", "床效（单床产出）", "人效（单员工产出）"])

if eff_type == "坪效（单位面积产出）":
    st.header("🏠 坪效计算")
    income = st.number_input("年营业收入（元）", min_value=0.0, format="%.2f")
    area = st.number_input("使用面积（平方米）", min_value=0.0, format="%.2f")
    if area > 0:
        eff = income / area
        st.success(f"坪效为：{eff:.2f} 元/㎡")
    else:
        st.info("请输入有效的面积")

elif eff_type == "床效（单床产出）":
    st.header("🛏️ 床效计算")
    income = st.number_input("年营业收入（元）", min_value=0.0, format="%.2f", key="income_bed")
    beds = st.number_input("实际运营床位数", min_value=1, step=1)
    if beds > 0:
        eff = income / beds
        st.success(f"床效为：{eff:.2f} 元/床")
    else:
        st.info("请输入有效的床位数")

elif eff_type == "人效（单员工产出）":
    st.header("👩‍⚕️ 人效计算")
    income = st.number_input("年营业收入（元）", min_value=0.0, format="%.2f", key="income_staff")
    staff = st.number_input("员工总人数", min_value=1, step=1)
    if staff > 0:
        eff = income / staff
        st.success(f"人效为：{eff:.2f} 元/人")
    else:
        st.info("请输入有效的员工人数")
