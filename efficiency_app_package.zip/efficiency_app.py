
import tkinter as tk
from tkinter import messagebox

def calculate_area_efficiency():
    try:
        income = float(entry_income_area.get())
        area = float(entry_area.get())
        result = income / area
        label_result_area.config(text=f"坪效：{result:.2f} 元/㎡")
    except:
        messagebox.showerror("错误", "请输入有效数字")

def calculate_bed_efficiency():
    try:
        income = float(entry_income_bed.get())
        beds = int(entry_beds.get())
        result = income / beds
        label_result_bed.config(text=f"床效：{result:.2f} 元/床")
    except:
        messagebox.showerror("错误", "请输入有效数字")

def calculate_staff_efficiency():
    try:
        income = float(entry_income_staff.get())
        staff = int(entry_staff.get())
        result = income / staff
        label_result_staff.config(text=f"人效：{result:.2f} 元/人")
    except:
        messagebox.showerror("错误", "请输入有效数字")

app = tk.Tk()
app.title("效率计算器")

# 坪效
tk.Label(app, text="【坪效】单位：元/㎡").grid(row=0, column=0, columnspan=2, pady=(10, 0))
tk.Label(app, text="总收入（元）:").grid(row=1, column=0)
entry_income_area = tk.Entry(app)
entry_income_area.grid(row=1, column=1)
tk.Label(app, text="使用面积（㎡）:").grid(row=2, column=0)
entry_area = tk.Entry(app)
entry_area.grid(row=2, column=1)
tk.Button(app, text="计算坪效", command=calculate_area_efficiency).grid(row=3, column=0, columnspan=2)
label_result_area = tk.Label(app, text="")
label_result_area.grid(row=4, column=0, columnspan=2, pady=(0, 10))

# 床效
tk.Label(app, text="【床效】单位：元/床").grid(row=5, column=0, columnspan=2)
tk.Label(app, text="总收入（元）:").grid(row=6, column=0)
entry_income_bed = tk.Entry(app)
entry_income_bed.grid(row=6, column=1)
tk.Label(app, text="床位数:").grid(row=7, column=0)
entry_beds = tk.Entry(app)
entry_beds.grid(row=7, column=1)
tk.Button(app, text="计算床效", command=calculate_bed_efficiency).grid(row=8, column=0, columnspan=2)
label_result_bed = tk.Label(app, text="")
label_result_bed.grid(row=9, column=0, columnspan=2, pady=(0, 10))

# 人效
tk.Label(app, text="【人效】单位：元/人").grid(row=10, column=0, columnspan=2)
tk.Label(app, text="总收入（元）:").grid(row=11, column=0)
entry_income_staff = tk.Entry(app)
entry_income_staff.grid(row=11, column=1)
tk.Label(app, text="员工数:").grid(row=12, column=0)
entry_staff = tk.Entry(app)
entry_staff.grid(row=12, column=1)
tk.Button(app, text="计算人效", command=calculate_staff_efficiency).grid(row=13, column=0, columnspan=2)
label_result_staff = tk.Label(app, text="")
label_result_staff.grid(row=14, column=0, columnspan=2, pady=(0, 10))

app.mainloop()
