# Efficiency Calculator App

This app calculates:
- 坪效（Area Efficiency）
- 床效（Bed Efficiency）
- 人效（Staff Efficiency）

All units are standardized in Chinese Yuan (元).
